import java.util.Stack;

public class PopDemo {
    public static void main(String[] args) {
        // Initialize a stack
        Stack<String> stack = new Stack<>();

        // Add elements to the stack
        stack.push("Apple");
        stack.push("Banana");
        stack.push("Cherry");

        // Pop an element from the stack
        if (!stack.isEmpty()) {
            String removedElement = stack.pop();
            System.out.println("Popped element: " + removedElement);
        }

        // Display the stack after the pop
        System.out.println("Stack after pop: " + stack);
    }
}