import java.util.Stack;

public class PeekDemo {
    public static void main(String[] args) {
        // Initialize a stack
        Stack<Double> stack = new Stack<>();

        // Add elements to the stack
        stack.push(3.14);
        stack.push(2.71);
        stack.push(1.61);

        // Peek at the top element without removing it
        if (!stack.isEmpty()) {
            Double topElement = stack.peek();
            System.out.println("Top element: " + topElement);
        } else {
            System.out.println("Stack is empty, nothing to peek.");
        }
    }
}