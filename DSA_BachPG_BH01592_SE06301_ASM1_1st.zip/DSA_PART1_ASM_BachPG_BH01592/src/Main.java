import java.util.Stack;
public class Main {
    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();

        // Push elements onto the stack
        stack.push("First");
        stack.push("Second");
        stack.push("Third");

        // Display the current stack
        System.out.println("Current stack: " + stack);

        // Pop an element from the stack
        String removedElement = stack.pop();
        System.out.println("Popped element: " + removedElement);

        // Check the top element without removing it
        String topElement = stack.peek();
        System.out.println("Top element: " + topElement);

        // Check if the stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is the stack empty? " + isEmpty);

        // Display the stack after popping
        System.out.println("Stack after pop: " + stack);

        // Get the size of the stack
        int size = stack.size();
        System.out.println("Size of the stack: " + size);
    }
}