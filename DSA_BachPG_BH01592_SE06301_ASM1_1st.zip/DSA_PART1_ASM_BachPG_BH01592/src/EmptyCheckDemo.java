import java.util.Stack;

public class EmptyCheckDemo {
    public static void main(String[] args) {
        // Initialize a stack
        Stack<Character> stack = new Stack<>();

        // Check if the stack is empty initially
        System.out.println("Is the stack empty? " + stack.isEmpty());

        // Push characters 'A', 'B', 'C', 'D', 'E' onto the stack
        stack.push('A');
        stack.push('B');
        stack.push('C');
        stack.push('D');
        stack.push('E');

        // Display the stack after pushing elements
        System.out.println("Stack after pushing elements: " + stack);

        // Check if the stack is empty
        System.out.println("Is the stack empty? " + stack.isEmpty());

        // Pop all elements from the stack
        while (!stack.isEmpty()) {
            System.out.println("Popped element: " + stack.pop());
        }

        // Check if the stack is empty after popping all elements
        System.out.println("Is the stack empty after popping all elements? " + stack.isEmpty());
    }
}