import java.util.Stack;

public class PushDemo {
    public static void main(String[] args) {
        // Initialize a stack
        Stack<Integer> stack = new Stack<>();

        // Push elements onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Display the stack
        System.out.println("After push operations, the stack: " + stack);
    }
}